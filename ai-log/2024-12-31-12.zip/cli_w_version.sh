# Initialize variables with default values
$username = ""
$password = ""
$zipFile = ""

# Function to display script usage
function Show-Usage {
    Write-Host "Usage: $scriptName -u <username> -p <password> -f <zipFile>"
    exit 1
}

# Parse command line options
param(
    [string]$username,
    [string]$password,
    [string]$zipFile
)

if (-not $username) {
    Write-Host "Error: Missing required option -u (username)."
    Show-Usage
}

if (-not $password) {
    Write-Host "Error: Missing required option -p (password)."
    Show-Usage
}

if (-not $zipFile) {
    Write-Host "Error: Missing required option -f (ZIP file path)."
    Show-Usage
}

# Set the endpoint URL
$endpoint = "http://galileo.softlab.ntua.gr:5000/upload"

# Build the form data
$formData = @{
    username = $username
    password = $password
    file = [System.IO.File]::ReadAllBytes($zipFile)
}

# Perform the POST request
try {
    $response = Invoke-RestMethod -Uri $endpoint -Method Post -Form $formData
    Write-Host "Server Response:"
    Write-Host ($response | ConvertTo-Json -Depth 10)
} catch {
    Write-Host "Error: $($error[0].Exception.Message)"
}